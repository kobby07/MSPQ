<?php
    DEFINE ('DB_HOST','localhost');
    DEFINE ('DB_NAME','aca_board');
    //DEFINE ('DB_NAME','acaboard_board');
    
    DEFINE ('DB_USER','root');
    //DEFINE ('DB_USER','acaboard_ghaff');
    DEFINE ('DB_PASSWORD','iambad0245389652');

     $db = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
?>